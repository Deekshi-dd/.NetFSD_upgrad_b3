﻿using ECommerce.API.Data;
using ECommerce.API.Models;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _context;

        public ProductRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ Get All
        public List<Product> GetAll()
        {
            return _context.Products
                .Include(p => p.OrderItems)
                .ToList();
        }

        // ✅ Get By Id
        public Product? GetById(int id)
        {
            return _context.Products.Find(id);
        }

        // ✅ Add
        public Product Add(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
            return product;
        }

        // ✅ Update
        public Product Update(int id, Product updatedProduct)
        {
            var product = _context.Products.Find(id);
            if (product == null)
                return null;

            product.Name = updatedProduct.Name;
            product.Description = updatedProduct.Description;
            product.ImageUrl = updatedProduct.ImageUrl;
            product.Price = updatedProduct.Price;

            _context.SaveChanges();
            return product;
        }

        // ✅ Delete
        public bool Delete(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null)
                return false;

            _context.Products.Remove(product);
            _context.SaveChanges();
            return true;
        }
    }
}