﻿namespace ECommerce.API.Authorization
{
    public static class Roles
    {
        // Admin role
        public const string Admin = "Admin";

        // Customer role
        public const string Customer = "Customer";

        // Combined roles (Admin OR Customer)
        public const string AdminOrCustomer = "Admin,Customer";
    }
}
