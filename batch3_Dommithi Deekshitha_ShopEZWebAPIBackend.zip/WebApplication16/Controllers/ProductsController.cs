﻿using ECommerce.API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ECommerce.API.DTOs;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Authorization;
using ECommerce.API.Authorization;

namespace ECommerce.API.Controllers
{
    [Authorize]
    [Route("api/products")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly ProductService _service;

        public ProductsController(ProductService service)
        {
            _service = service;
        }

        // ✅ GET: api/products
        [Authorize(Roles = Roles.AdminOrCustomer)]
        [HttpGet]
        public IActionResult GetAllProducts()
        {
            var products = _service.GetAllProducts();
            return Ok(products);
        }

        // ✅ GET: api/products/{id}
        [Authorize(Roles = Roles.AdminOrCustomer)]
        [HttpGet("{id}")]
        public IActionResult GetProductById(int id)
        {
            var product = _service.GetProductById(id);

            if (product == null)
                return NotFound();

            return Ok(product);
        }

        // ✅ POST: api/products
        [Authorize(Roles = Roles.Admin)]  
        [HttpPost]
        public IActionResult AddProduct(Product product)
        {
            var newProduct = _service.AddProduct(product);
            return Ok(newProduct);   // ✅ returns ID also
        }

        // ✅ PUT: api/products/{id}
        [Authorize(Roles = Roles.Admin)]
        [HttpPut("{id}")]
        public IActionResult UpdateProduct(int id, Product product)
        {
            var updatedProduct = _service.UpdateProduct(id, product);

            if (updatedProduct == null)
                return NotFound();

            return Ok(updatedProduct);
        }

        // ✅ DELETE: api/products/{id}
        [Authorize(Roles = Roles.Admin)]
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var isDeleted = _service.DeleteProduct(id);

            if (!isDeleted)
                return NotFound();

            return Ok("Product deleted successfully");
        }
    }
}