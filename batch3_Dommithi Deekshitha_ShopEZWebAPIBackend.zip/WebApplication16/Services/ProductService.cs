﻿using ECommerce.API.Data;
using ECommerce.API.DTOs;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.API.Services
{
    public class ProductService
    {
        private readonly ApplicationDbContext _context;

        public ProductService(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ Get All Products
        public List<Product> GetAllProducts()
        {
            return _context.Products
                .Include(p => p.OrderItems)
                .ToList();
        }

        // ✅ Get Product By Id
        public Product GetProductById(int id)
        {
            return _context.Products.FirstOrDefault(p => p.Id == id);
        }

        // ✅ Add Product
        public Product AddProduct(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();

            return product; // 
        }

        // ✅ Update Product
        public Product UpdateProduct(int id, Product updatedProduct)
        {
            var product = _context.Products.FirstOrDefault(p => p.Id == id);

            if (product == null)
                return null;

            product.Name = updatedProduct.Name;
            product.Description = updatedProduct.Description;
            product.ImageUrl = updatedProduct.ImageUrl;
            product.Price = updatedProduct.Price;

            _context.SaveChanges();

            return product;
        }

        // ✅ Delete Product
        public bool DeleteProduct(int id)
        {
            var product = _context.Products.FirstOrDefault(p => p.Id == id);

            if (product == null)
                return false;

            _context.Products.Remove(product);
            _context.SaveChanges();

            return true;
        }
    }
}