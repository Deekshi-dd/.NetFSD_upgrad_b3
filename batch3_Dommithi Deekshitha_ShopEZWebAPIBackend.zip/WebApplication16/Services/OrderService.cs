﻿
using ECommerce.API.Data;
using ECommerce.API.Models;
using ECommerce.API.DTOs;
using Microsoft.EntityFrameworkCore;
using System.Linq;
namespace ECommerce.API.Services
{
    public class OrderService
    {
        private readonly ApplicationDbContext _context;

        // 🔌 Dependency Injection
        public OrderService(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ CREATE ORDER (Core Logic)
        public async Task<Order> CreateOrder(OrderDTO dto)
        {
            if (dto == null || dto.OrderItems == null || !dto.OrderItems.Any())
                throw new Exception("Cart is empty");

            var order = new Order
            {
                UserId = dto.UserId,
                OrderDate = DateTime.Now,
                OrderItems = new List<OrderItem>()
            };

            foreach (var item in dto.OrderItems)
            {
                var product = await _context.Products.FindAsync(item.ProductId);

                if (product == null)
                    throw new Exception($"Product with ID {item.ProductId} not found");

                if (item.Quantity <= 0)
                    throw new Exception("Quantity must be greater than zero");

                order.OrderItems.Add(new OrderItem
                {
                    ProductId = product.Id,
                    Quantity = item.Quantity,
                    Price = product.Price
                });
            }

            order.TotalAmount = order.OrderItems.Sum(x => x.Price * x.Quantity);

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            return order;
        }
        
        // ✅ GET ALL ORDERS
        public async Task<List<Order>> GetAllOrders()
        {
            return await _context.Orders
                .Include(o => o.OrderItems)
                .ToListAsync();
        }

        // ✅ GET ORDER BY ID
        public async Task<Order> GetOrderById(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .FirstOrDefaultAsync(o => o.OrderId == id);

            if (order == null)
                throw new Exception("Order not found");

            return order;
        }
        public async Task<List<Order>> GetOrdersByUserId(int userId)
        {
            return await _context.Orders
                .Where(o => o.UserId == userId)
                .Include(o => o.OrderItems)
                .ToListAsync();
        }
    }  
}       