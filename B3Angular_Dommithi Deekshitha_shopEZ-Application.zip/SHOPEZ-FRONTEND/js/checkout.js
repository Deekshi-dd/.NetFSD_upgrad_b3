$(document).ready(function () {
  displaySummary();
});

function displaySummary() {
  let cart = getCart();
  let total = 0;

  cart.forEach(item => {
    total += item.price;
  });

  $("#totalAmount").text(total);
}

$("#checkoutForm").submit(function (e) {
  e.preventDefault();
  alert("Order Placed Successfully!");
  localStorage.removeItem("cart");
  window.location.href = "index.html";
});