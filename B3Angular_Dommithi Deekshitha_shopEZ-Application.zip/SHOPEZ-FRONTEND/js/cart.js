function addToCart(product) {
  let cart = getCart();
  cart.push(product);
  saveCart(cart);
  alert("Added to cart");
}

function loadCart() {
  let cart = getCart();
  let output = "";
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;

    output += `
      <tr>
        <td>${item.name}</td>
        <td>₹${item.price}</td>
        <td><button onclick="removeItem(${index})" class="btn btn-danger">Remove</button></td>
      </tr>
    `;
  });

  $("#cartItems").html(output);
  $("#total").text(total);
}

function removeItem(index) {
  let cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
  loadCart();
}