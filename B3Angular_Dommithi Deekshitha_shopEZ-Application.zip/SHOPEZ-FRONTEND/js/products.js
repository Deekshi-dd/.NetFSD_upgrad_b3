$(document).ready(function () {
  loadProducts();
});

function loadProducts() {
  $.getJSON("data/products.json", function (products) {
    displayProducts(products);
  });
}

function displayProducts(products) {
  let output = "";

  products.forEach(product => {
    output += `
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="${product.image}" class="card-img-top">
          <div class="card-body">
            <h5>${product.name}</h5>
            <p>₹${product.price}</p>
            <a href="product-details.html?id=${product.id}" class="btn btn-primary">View</a>
            <button class="btn btn-success" onclick='addToCart(${JSON.stringify(product)})'>Add</button>
          </div>
        </div>
      </div>
    `;
  });

  $("#productList").html(output);
}